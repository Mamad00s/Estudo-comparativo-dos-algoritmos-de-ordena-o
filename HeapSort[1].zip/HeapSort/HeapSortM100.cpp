#include <iostream>
#include <vector>
#include <chrono>

using namespace std;
using namespace std::chrono;

// Função para construir o heap máximo
void heapify(vector<int>& arr, int n, int i, long long& comparacoes, long long& trocas) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    if (left < n) {
        comparacoes++;  // Contagem de comparação
        if (arr[left] > arr[largest])
            largest = left;
    }

    if (right < n) {
        comparacoes++;  // Contagem de comparação
        if (arr[right] > arr[largest])
            largest = right;
    }

    if (largest != i) {
        swap(arr[i], arr[largest]);
        trocas++;  // Contagem de troca
        heapify(arr, n, largest, comparacoes, trocas);
    }
}

// Função Heap Sort
void heapSort(vector<int>& arr, long long& comparacoes, long long& trocas) {
    int n = arr.size();

    for (int i = n / 2 - 1; i >= 0; i--)
        heapify(arr, n, i, comparacoes, trocas);

    for (int i = n - 1; i >= 0; i--) {
        swap(arr[0], arr[i]);
        trocas++;  // Contagem de troca
        heapify(arr, i, 0, comparacoes, trocas);
    }
}

// Função para gerar dados em ordem crescente
vector<int> gerarCrescente(int tamanho) {
    vector<int> arr(tamanho);
    for (int i = 0; i < tamanho; ++i)
        arr[i] = i;  // Gera em ordem crescente
    return arr;
}

int main() {
    int tamanho = 100000;  // 100.000 elementos
    vector<int> arr = gerarCrescente(tamanho);

    long long comparacoes = 0;
    long long trocas = 0;

    auto inicio = high_resolution_clock::now();
    heapSort(arr, comparacoes, trocas);
    auto fim = high_resolution_clock::now();

    auto duracao = duration_cast<milliseconds>(fim - inicio);
    cout << "Melhor Caso (100.000 elementos): " << duracao.count() << " ms" << endl;
    cout << "Comparações realizadas: " << comparacoes << endl;
    cout << "Trocas realizadas: " << trocas << endl;

    return 0;
}
