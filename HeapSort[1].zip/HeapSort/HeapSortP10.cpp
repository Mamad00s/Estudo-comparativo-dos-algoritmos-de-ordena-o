#include <iostream>
#include <vector>
#include <chrono>

using namespace std;
using namespace std::chrono;

// Variáveis globais para contagem de comparações e trocas
int comparacoes = 0;
int trocas = 0;

// Função para construir o heap máximo
void heapify(vector<int>& arr, int n, int i) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    // Comparação com o filho da esquerda
    if (left < n) {
        comparacoes++;  // Conta a comparação
        if (arr[left] > arr[largest])
            largest = left;
    }

    // Comparação com o filho da direita
    if (right < n) {
        comparacoes++;  // Conta a comparação
        if (arr[right] > arr[largest])
            largest = right;
    }

    // Se o maior não for o índice inicial, troca e chama recursivamente
    if (largest != i) {
        trocas++;  // Conta a troca
        swap(arr[i], arr[largest]);
        heapify(arr, n, largest);
    }
}

// Função Heap Sort
void heapSort(vector<int>& arr) {
    int n = arr.size();

    // Construir o heap máximo
    for (int i = n / 2 - 1; i >= 0; i--)
        heapify(arr, n, i);

    // Extrair elementos do heap um por um
    for (int i = n - 1; i >= 0; i--) {
        trocas++;  // Conta a troca
        swap(arr[0], arr[i]);
        heapify(arr, i, 0);
    }
}

// Função para gerar dados em ordem decrescente
vector<int> gerarDecrescente(int tamanho) {
    vector<int> arr(tamanho);
    for (int i = 0; i < tamanho; ++i)
        arr[i] = tamanho - i;  // Gera em ordem decrescente
    return arr;
}

int main() {
    int tamanho = 10000;  // 10.000 elementos
    vector<int> arr = gerarDecrescente(tamanho);

    auto inicio = high_resolution_clock::now();
    heapSort(arr);
    auto fim = high_resolution_clock::now();

    auto duracao = duration_cast<milliseconds>(fim - inicio);
    cout << "Pior Caso (10.000 elementos): " << duracao.count() << " ms" << endl;
    cout << "Número de Comparações: " << comparacoes << endl;
    cout << "Número de Trocas: " << trocas << endl;

    return 0;
}
