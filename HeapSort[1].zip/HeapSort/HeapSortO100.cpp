#include <iostream>
#include <vector>
#include <chrono>
#include <cstdlib>

using namespace std;
using namespace std::chrono;

// Função para construir o heap máximo
void heapify(vector<int>& arr, int n, int i, long long& comparacoes, long long& trocas) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    // Comparações
    if (left < n) {
        comparacoes++;
        if (arr[left] > arr[largest]) {
            largest = left;
        }
    }

    if (right < n) {
        comparacoes++;
        if (arr[right] > arr[largest]) {
            largest = right;
        }
    }

    if (largest != i) {
        swap(arr[i], arr[largest]);
        trocas++;  // Contagem de trocas
        heapify(arr, n, largest, comparacoes, trocas);
    }
}

// Função Heap Sort
void heapSort(vector<int>& arr, long long& comparacoes, long long& trocas) {
    int n = arr.size();

    // Construir o heap máximo
    for (int i = n / 2 - 1; i >= 0; i--)
        heapify(arr, n, i, comparacoes, trocas);

    // Extrair elementos do heap um por um
    for (int i = n - 1; i >= 0; i--) {
        swap(arr[0], arr[i]);
        trocas++;  // Contagem de trocas
        heapify(arr, i, 0, comparacoes, trocas);
    }
}

// Função para gerar dados aleatórios
vector<int> gerarAleatorio(int tamanho) {
    vector<int> arr(tamanho);
    for (int i = 0; i < tamanho; ++i)
        arr[i] = rand() % (tamanho * 10); // Números aleatórios
    return arr;
}

int main() {
    int tamanho = 100000;  // 100.000 elementos
    vector<int> arr = gerarAleatorio(tamanho);

    long long comparacoes = 0;
    long long trocas = 0;

    auto inicio = high_resolution_clock::now();
    heapSort(arr, comparacoes, trocas);
    auto fim = high_resolution_clock::now();

    auto duracao = duration_cast<milliseconds>(fim - inicio);
    cout << "Caso Médio (100.000 elementos): " << duracao.count() << " ms" << endl;
    cout << "Comparações realizadas: " << comparacoes << endl;
    cout << "Trocas realizadas: " << trocas << endl;

    return 0;
}
