#include <iostream>
#include <vector>
#include <chrono>

using namespace std;
using namespace std::chrono;

// Função para construir o heap máximo
void heapify(vector<int>& arr, int n, int i, long long& comparacoes, long long& trocas) {
    int largest = i;
    int left = 2 * i + 1;
    int right = 2 * i + 2;

    // Comparação entre o nó pai e o filho esquerdo
    if (left < n) {
        comparacoes++;  // Contagem de comparação
        if (arr[left] > arr[largest])
            largest = left;
    }

    // Comparação entre o nó pai e o filho direito
    if (right < n) {
        comparacoes++;  // Contagem de comparação
        if (arr[right] > arr[largest])
            largest = right;
    }

    // Se o maior não for o nó atual, troque e continue a reparação do heap
    if (largest != i) {
        swap(arr[i], arr[largest]);
        trocas++;  // Contagem de troca
        heapify(arr, n, largest, comparacoes, trocas);
    }
}

// Função Heap Sort
void heapSort(vector<int>& arr, long long& comparacoes, long long& trocas) {
    int n = arr.size();

    // Construir o heap máximo
    for (int i = n / 2 - 1; i >= 0; i--)
        heapify(arr, n, i, comparacoes, trocas);

    // Extrair elementos do heap um por um
    for (int i = n - 1; i >= 0; i--) {
        swap(arr[0], arr[i]);
        trocas++;  // Contagem de troca
        heapify(arr, i, 0, comparacoes, trocas);
    }
}

// Função para gerar dados em ordem crescente
vector<int> gerarCrescente(int tamanho) {
    vector<int> arr(tamanho);
    for (int i = 0; i < tamanho; ++i)
        arr[i] = i;  // Gera em ordem crescente
    return arr;
}

int main() {
    int tamanho = 1000;  // 1.000 elementos
    vector<int> arr = gerarCrescente(tamanho);

    long long comparacoes = 0;  // Contador de comparações
    long long trocas = 0;       // Contador de trocas

    auto inicio = high_resolution_clock::now();
    heapSort(arr, comparacoes, trocas);
    auto fim = high_resolution_clock::now();

    auto duracao = duration_cast<milliseconds>(fim - inicio);
    cout << "Melhor Caso (1.000 elementos): " << duracao.count() << " ms" << endl;
    cout << "Comparações realizadas: " << comparacoes << endl;
    cout << "Trocas realizadas: " << trocas << endl;

    return 0;
}
