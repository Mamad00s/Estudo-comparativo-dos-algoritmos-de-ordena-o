#include <iostream>
#include <vector>
#include <chrono>

using namespace std;
using namespace std::chrono;

// Variáveis globais para contagem de comparações e trocas
int comparacoes = 0;
int trocas = 0;

// Função para particionar o vetor
int partition(vector<int>& arr, int low, int high) {
    int pivot = arr[high];
    int i = low - 1;

    for (int j = low; j < high; j++) {
        comparacoes++;  // Conta a comparação
        if (arr[j] <= pivot) {
            i++;
            trocas++;  // Conta a troca
            swap(arr[i], arr[j]);
        }
    }

    trocas++;  // Conta a troca final
    swap(arr[i + 1], arr[high]);
    return i + 1;
}

// Função Quick Sort
void quickSort(vector<int>& arr, int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

// Função para gerar dados em ordem crescente
vector<int> gerarCrescente(int tamanho) {
    vector<int> arr(tamanho);
    for (int i = 0; i < tamanho; ++i)
        arr[i] = i;  // Gera em ordem crescente
    return arr;
}

int main() {
    int tamanho = 10000;  // 10.000 elementos
    vector<int> arr = gerarCrescente(tamanho);

    auto inicio = high_resolution_clock::now();
    quickSort(arr, 0, arr.size() - 1);
    auto fim = high_resolution_clock::now();

    auto duracao = duration_cast<milliseconds>(fim - inicio);
    cout << "Melhor Caso (10.000 elementos): " << duracao.count() << " ms" << endl;
    cout << "Número de Comparações: " << comparacoes << endl;
    cout << "Número de Trocas: " << trocas << endl;

    return 0;
}
