#include <iostream>
#include <vector>
#include <chrono>

using namespace std;
using namespace std::chrono;

// Variáveis globais para contar as comparações e trocas
int contagemComparacoes = 0;
int contagemTrocas = 0;

// Função para particionar o vetor
int partition(vector<int>& arr, int low, int high) {
    int pivot = arr[high];
    int i = low - 1;

    for (int j = low; j < high; j++) {
        contagemComparacoes++;  // Incrementa a comparação
        if (arr[j] <= pivot) {
            i++;
            swap(arr[i], arr[j]);
            contagemTrocas++;  // Incrementa a troca
        }
    }

    swap(arr[i + 1], arr[high]);
    contagemTrocas++;  // Incrementa a troca
    return i + 1;
}

// Função Quick Sort
void quickSort(vector<int>& arr, int low, int high) {
    if (low < high) {
        int pi = partition(arr, low, high);
        quickSort(arr, low, pi - 1);
        quickSort(arr, pi + 1, high);
    }
}

// Função para gerar dados em ordem decrescente
vector<int> gerarDecrescente(int tamanho) {
    vector<int> arr(tamanho);
    for (int i = 0; i < tamanho; ++i)
        arr[i] = tamanho - i;  // Gera em ordem decrescente
    return arr;
}

int main() {
    int tamanho = 1000;  // 1.000 elementos
    vector<int> arr = gerarDecrescente(tamanho);

    auto inicio = high_resolution_clock::now();
    quickSort(arr, 0, arr.size() - 1);
    auto fim = high_resolution_clock::now();

    auto duracao = duration_cast<milliseconds>(fim - inicio);
    cout << "Pior Caso (1.000 elementos): " << duracao.count() << " ms" << endl;
    cout << "Comparações: " << contagemComparacoes << endl;
    cout << "Trocas: " << contagemTrocas << endl;

    return 0;
}
