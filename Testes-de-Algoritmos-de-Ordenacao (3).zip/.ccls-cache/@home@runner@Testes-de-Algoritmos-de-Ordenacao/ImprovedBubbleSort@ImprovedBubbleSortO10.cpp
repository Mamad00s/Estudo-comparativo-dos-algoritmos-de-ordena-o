#include <iostream>
#include <vector>
#include <chrono>  // Para medir o tempo de execução
#include <random>  // Para gerar números aleatórios

using namespace std;
using namespace chrono;

// Função de ordenação Improved Bubble Sort
void improvedBubbleSort(vector<int>& arr, long long& comparacoes, long long& trocas) {
    int n = arr.size();
    bool trocou;
    int ultimaTroca = n - 1;  // Última posição trocada
    comparacoes = 0;
    trocas = 0;

    while (ultimaTroca > 0) {
        int novoLimite = 0;
        trocou = false;
        // Passa pelo vetor até a última troca
        for (int j = 0; j < ultimaTroca; ++j) {
            ++comparacoes;  // Incrementa o contador de comparações
            if (arr[j] > arr[j + 1]) {
                swap(arr[j], arr[j + 1]);
                ++trocas;  // Incrementa o contador de trocas
                trocou = true;
                novoLimite = j;  // Atualiza a última posição trocada
            }
        }
        ultimaTroca = novoLimite;  // Ajusta o limite da próxima iteração
        // Se não houve troca, o vetor já está ordenado
        if (!trocou) {
            break;
        }
    }
}

// Função global para medir o tempo de execução
void medirTempoExecucao(void (*func)(vector<int>&, long long&, long long&), vector<int>& arr) {
    long long comparacoes = 0;
    long long trocas = 0;

    auto inicio = high_resolution_clock::now();  // Marca o tempo de início
    func(arr, comparacoes, trocas);  // Executa a função de ordenação
    auto fim = high_resolution_clock::now();  // Marca o tempo de término

    auto duracao = duration_cast<microseconds>(fim - inicio);  // Calcula a duração
    cout << "Tempo de execução: " << duracao.count() << " microsegundos." << endl;
    cout << "Total de comparações: " << comparacoes << endl;
    cout << "Total de trocas: " << trocas << endl;
}

int main() {
    // Gerar um vetor com 10000 números aleatórios
    int n = 10000;
    vector<int> arr(n);

    // Gerar números aleatórios entre 1 e 10000 para preencher o vetor
    random_device rd;  // Obtém um número aleatório do sistema
    mt19937 gen(rd()); // Gerador de números aleatórios
    uniform_int_distribution<> distrib(1, 10000); // Define o intervalo de números aleatórios

    // Preencher o vetor com números aleatórios
    for (int i = 0; i < n; ++i) {
        arr[i] = distrib(gen);  // Preenche o vetor com números aleatórios entre 1 e 10000
    }

    // Medir o tempo de execução do Improved Bubble Sort
    medirTempoExecucao(improvedBubbleSort, arr);

    // Mensagem indicando que a ordenação foi concluída
    cout << "Ordenação concluída!" << endl;

    // Caso deseje imprimir o vetor ordenado (opcional)
    // for (int i = 0; i < 10; ++i) {  // Apenas mostrando os 10 primeiros números
    //     cout << arr[i] << " ";
    // }
    // cout << endl;

    return 0;
}
