#include <iostream>
#include <vector>
#include <chrono>  // Para medir o tempo de execução

using namespace std;
using namespace chrono;

// Função de ordenação Improved Bubble Sort
void improvedBubbleSort(vector<int>& arr) {
    int n = arr.size();
    bool trocou;
    int ultimaTroca = n - 1;  // Última posição trocada
    while (ultimaTroca > 0) {
        int novoLimite = 0;
        trocou = false;
        // Passa pelo vetor até a última troca
        for (int j = 0; j < ultimaTroca; ++j) {
            if (arr[j] > arr[j + 1]) {
                swap(arr[j], arr[j + 1]);
                trocou = true;
                novoLimite = j;  // Atualiza a última posição trocada
            }
        }
        ultimaTroca = novoLimite;  // Ajusta o limite da próxima iteração
        // Se não houve troca, o vetor já está ordenado
        if (!trocou) {
            break;
        }
    }
}

// Função global para medir o tempo de execução
void medirTempoExecucao(void (*func)(vector<int>&), vector<int>& arr) {
    auto inicio = high_resolution_clock::now();  // Marca o tempo de início
    func(arr);  // Executa a função de ordenação
    auto fim = high_resolution_clock::now();  // Marca o tempo de término

    auto duracao = duration_cast<microseconds>(fim - inicio);  // Calcula a duração
    cout << "Tempo de execução: " << duracao.count() << " microsegundos." << endl;
}

int main() {
    // Gerar um vetor com 1000 números já ordenados
    int n = 1000;
    vector<int> arr(n);

    // Preencher o vetor com números de 1 a 1000 (já ordenados)
    for (int i = 0; i < n; ++i) {
        arr[i] = i + 1;  // Vetor de 1 a 1000
    }

    // Medir o tempo de execução do Improved Bubble Sort
    medirTempoExecucao(improvedBubbleSort, arr);

    // Mensagem indicando que a ordenação foi concluída
    cout << "Ordenação concluída!" << endl;

    // Caso deseje imprimir o vetor ordenado (opcional)
    // for (int i = 0; i < 10; ++i) {  // Apenas mostrando os 10 primeiros números
    //     cout << arr[i] << " ";
    // }
    // cout << endl;

    return 0;
}

