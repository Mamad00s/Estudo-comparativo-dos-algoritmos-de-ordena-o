#include <iostream>
#include <vector>
#include <chrono>  // Para medir o tempo de execução
#include <cstdlib>  // Para gerar números aleatórios
#include <ctime>    // Para inicializar o gerador de números aleatórios

using namespace std;
using namespace chrono;

// Função de ordenação Bubble Sort com contagem de trocas e comparações
void bubbleSort(vector<int>& arr, int& comparacoes, int& trocas) {
    int n = arr.size();
    bool trocou;
    for (int i = 0; i < n - 1; ++i) {
        trocou = false;
        // Passa pelo vetor, comparando e trocando elementos
        for (int j = 0; j < n - 1 - i; ++j) {
            ++comparacoes; // Incrementa o contador de comparações
            if (arr[j] > arr[j + 1]) {
                swap(arr[j], arr[j + 1]);
                ++trocas; // Incrementa o contador de trocas
                trocou = true;
            }
        }
        // Se não houve troca, o vetor já está ordenado
        if (!trocou) {
            break;
        }
    }
}

// Função global para medir o tempo de execução
void medirTempoExecucao(void (*func)(vector<int>&, int&, int&), vector<int>& arr) {
    int comparacoes = 0;
    int trocas = 0;

    auto inicio = high_resolution_clock::now();  // Marca o tempo de início
    func(arr, comparacoes, trocas);  // Executa a função de ordenação
    auto fim = high_resolution_clock::now();  // Marca o tempo de término

    auto duracao = duration_cast<microseconds>(fim - inicio);  // Calcula a duração
    cout << "Tempo de execução: " << duracao.count() << " microsegundos." << endl;
    cout << "Número de comparações: " << comparacoes << endl;
    cout << "Número de trocas: " << trocas << endl;
}

// Função para gerar um vetor com números aleatórios
void gerarVetorAleatorio(vector<int>& arr) {
    for (int i = 0; i < arr.size(); ++i) {
        arr[i] = rand() % 10000;  // Números aleatórios entre 0 e 9.999
    }
}

int main() {
    srand(time(0));  // Inicializa o gerador de números aleatórios

    // Vetor com 10.000 números aleatórios
    int n = 10000;
    vector<int> arr(n);
    gerarVetorAleatorio(arr);

    // Medir o tempo de execução do algoritmo de ordenação
    medirTempoExecucao(bubbleSort, arr);

    // Mensagem indicando que a ordenação foi concluída
    cout << "Ordenação concluída!" << endl;

    return 0;
}
