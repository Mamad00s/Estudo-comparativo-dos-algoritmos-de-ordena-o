#include <iostream>
#include <vector>
#include <chrono>  // Para medir o tempo de execução

using namespace std;
using namespace chrono;

// Função de ordenação Bubble Sort
void bubbleSort(vector<int>& arr, int& comparacoes, int& trocas) {
    int n = arr.size();
    bool trocou;
    comparacoes = 0;
    trocas = 0;

    for (int i = 0; i < n - 1; ++i) {
        trocou = false;
        // Passa pelo vetor, comparando e trocando elementos
        for (int j = 0; j < n - 1 - i; ++j) {
            ++comparacoes; // Incrementa o número de comparações
            if (arr[j] > arr[j + 1]) {
                swap(arr[j], arr[j + 1]);
                ++trocas; // Incrementa o número de trocas
                trocou = true;
            }
        }
        // Se não houve troca, o vetor já está ordenado
        if (!trocou) {
            break;
        }
    }
}

// Função global para medir o tempo de execução
void medirTempoExecucao(void (*func)(vector<int>&, int&, int&), vector<int>& arr) {
    int comparacoes = 0, trocas = 0;
    auto inicio = high_resolution_clock::now();  // Marca o tempo de início
    func(arr, comparacoes, trocas);  // Executa a função de ordenação
    auto fim = high_resolution_clock::now();  // Marca o tempo de término

    auto duracao = duration_cast<microseconds>(fim - inicio);  // Calcula a duração
    cout << "Tempo de execução: " << duracao.count() << " microsegundos." << endl;
    cout << "Comparações realizadas: " << comparacoes << endl;
    cout << "Trocas realizadas: " << trocas << endl;
}

int main() {
    // Gerar um vetor com 1000 números já ordenados
    int n = 1000;
    vector<int> arr(n);

    // Preencher o vetor com números de 1 a 1000 (já ordenados)
    for (int i = 0; i < n; ++i) {
        arr[i] = i + 1;  // Vetor de 1 a 1000
    }

    // Medir o tempo de execução do algoritmo de ordenação
    medirTempoExecucao(bubbleSort, arr);

    // Mensagem indicando que a ordenação foi concluída
    cout << "Ordenação concluída!" << endl;

    // Caso deseje imprimir o vetor ordenado (opcional)
    // for (int i = 0; i < 10; ++i) {  // Apenas mostrando os 10 primeiros números
    //     cout << arr[i] << " ";
    // }
    // cout << endl;

    return 0;
}
