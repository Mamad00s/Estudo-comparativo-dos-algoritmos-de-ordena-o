#include <iostream>
#include <vector>
#include <chrono>  // Para medir o tempo de execução
#include <cstdlib>  // Para gerar números aleatórios
#include <ctime>    // Para inicializar o gerador de números aleatórios
#include <algorithm>  // Para usar o sort

using namespace std;
using namespace chrono;

// Função de ordenação Bubble Sort
void bubbleSort(vector<int>& arr, int& trocas, int& comparacoes) {
    int n = arr.size();
    bool trocou;
    for (int i = 0; i < n - 1; ++i) {
        trocou = false;
        // Passa pelo vetor, comparando e trocando elementos
        for (int j = 0; j < n - 1 - i; ++j) {
            comparacoes++;  // Incrementa o número de comparações
            if (arr[j] > arr[j + 1]) {
                swap(arr[j], arr[j + 1]);
                trocas++;  // Incrementa o número de trocas
                trocou = true;
            }
        }
        // Se não houve troca, o vetor já está ordenado
        if (!trocou) {
            break;
        }
    }
}

// Função para gerar um vetor com números aleatórios em ordem decrescente
void gerarVetorDecrescente(vector<int>& arr) {
    for (int i = 0; i < arr.size(); ++i) {
        arr[i] = rand() % 1000;  // Números aleatórios entre 0 e 999
    }
    // Ordenando o vetor em ordem decrescente
    sort(arr.begin(), arr.end(), greater<int>());
}

int main() {
    srand(time(0));  // Inicializa o gerador de números aleatórios

    // Vetor com 100.000 números aleatórios em ordem decrescente
    int n = 100000;
    vector<int> arr(n);
    gerarVetorDecrescente(arr);

    // Variáveis para contar trocas e comparações
    int trocas = 0;
    int comparacoes = 0;

    // Medir o tempo de execução do algoritmo de ordenação
    auto inicio = high_resolution_clock::now();
    bubbleSort(arr, trocas, comparacoes);
    auto fim = high_resolution_clock::now();

    auto duracao = duration_cast<microseconds>(fim - inicio);
    cout << "Tempo de execução (100000 elementos decrescentes): " << duracao.count() << " microsegundos." << endl;
    cout << "Número de comparações: " << comparacoes << endl;
    cout << "Número de trocas: " << trocas << endl;

    return 0;
}
