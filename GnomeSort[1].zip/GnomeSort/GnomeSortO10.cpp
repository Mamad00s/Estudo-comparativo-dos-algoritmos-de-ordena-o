#include <iostream>
#include <vector>
#include <chrono>
#include <cstdlib>

using namespace std;
using namespace std::chrono;

// Função Gnome Sort com contagem de operações
void gnomeSort(vector<int>& arr, long long& comparacoes, long long& trocas) {
    int n = arr.size();
    int index = 0;
    while (index < n) {
        if (index == 0)
            index++;
        comparacoes++; // Incrementa número de comparações
        if (arr[index] >= arr[index - 1]) {
            index++;
        } else {
            swap(arr[index], arr[index - 1]);
            trocas++; // Incrementa número de trocas
            index--;
        }
    }
}

// Função para gerar dados aleatórios
vector<int> gerarAleatorio(int tamanho) {
    vector<int> arr(tamanho);
    for (int i = 0; i < tamanho; ++i)
        arr[i] = rand() % (tamanho * 10); // Gera números aleatórios no intervalo [0, tamanho * 10]
    return arr;
}

int main() {
    srand(time(0)); // Inicializa a semente do gerador de números aleatórios
    int tamanho = 10000; // Tamanho do vetor: 10.000 elementos
    vector<int> arr = gerarAleatorio(tamanho);

    long long comparacoes = 0;
    long long trocas = 0;

    // Medir tempo de execução
    auto inicio = high_resolution_clock::now();
    gnomeSort(arr, comparacoes, trocas);
    auto fim = high_resolution_clock::now();

    auto duracao = duration_cast<milliseconds>(fim - inicio);
    
    // Exibir resultados
    cout << "Caso Médio (10.000 elementos): " << duracao.count() << " ms" << endl;
    cout << "Comparações realizadas: " << comparacoes << endl;
    cout << "Trocas realizadas: " << trocas << endl;

    return 0;
}
