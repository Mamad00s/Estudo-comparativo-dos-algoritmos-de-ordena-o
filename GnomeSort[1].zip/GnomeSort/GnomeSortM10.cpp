#include <iostream>
#include <vector>
#include <chrono>

using namespace std;
using namespace std::chrono;

// Função Gnome Sort com contagem de comparações e trocas
void gnomeSort(vector<int>& arr, int& comparacoes, int& trocas) {
    int n = arr.size();
    int index = 0;
    while (index < n) {
        if (index == 0)
            index++;
        comparacoes++;  // Comparação realizada no if
        if (arr[index] >= arr[index - 1]) {
            index++;
        } else {
            swap(arr[index], arr[index - 1]);
            trocas++;  // Incrementa trocas
            index--;
        }
    }
}

// Função para gerar dados em ordem crescente
vector<int> gerarCrescente(int tamanho) {
    vector<int> arr(tamanho);
    for (int i = 0; i < tamanho; ++i)
        arr[i] = i + 1;  // Gera em ordem crescente
    return arr;
}

int main() {
    int tamanho = 10000;  // 10.000 elementos
    vector<int> arr = gerarCrescente(tamanho);

    int comparacoes = 0;
    int trocas = 0;

    auto inicio = high_resolution_clock::now();
    gnomeSort(arr, comparacoes, trocas);
    auto fim = high_resolution_clock::now();

    auto duracao = duration_cast<milliseconds>(fim - inicio);
    cout << "Melhor Caso (10.000 elementos): " << duracao.count() << " ms" << endl;
    cout << "Comparações realizadas: " << comparacoes << endl;
    cout << "Trocas realizadas: " << trocas << endl;

    return 0;
}
