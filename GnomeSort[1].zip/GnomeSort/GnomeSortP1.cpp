#include <iostream>
#include <vector>
#include <chrono>

using namespace std;
using namespace std::chrono;

// Função Gnome Sort com contagem de operações
void gnomeSort(vector<int>& arr, long long& comparacoes, long long& trocas) {
    int n = arr.size();
    int index = 0;
    while (index < n) {
        if (index == 0)
            index++;
        comparacoes++; // Contando comparação
        if (arr[index] >= arr[index - 1]) {
            index++;
        } else {
            swap(arr[index], arr[index - 1]);
            trocas++; // Contando troca
            index--;
        }
    }
}

// Função para gerar dados em ordem decrescente
vector<int> gerarDecrescente(int tamanho) {
    vector<int> arr(tamanho);
    for (int i = 0; i < tamanho; ++i)
        arr[i] = tamanho - i;  // Gera em ordem decrescente
    return arr;
}

int main() {
    int tamanho = 1000;  // 1.000 elementos
    vector<int> arr = gerarDecrescente(tamanho);

    long long comparacoes = 0;
    long long trocas = 0;

    auto inicio = high_resolution_clock::now();
    gnomeSort(arr, comparacoes, trocas);
    auto fim = high_resolution_clock::now();

    auto duracao = duration_cast<milliseconds>(fim - inicio);

    cout << "Pior Caso (1.000 elementos): " << duracao.count() << " ms" << endl;
    cout << "Comparações realizadas: " << comparacoes << endl;
    cout << "Trocas realizadas: " << trocas << endl;

    return 0;
}
