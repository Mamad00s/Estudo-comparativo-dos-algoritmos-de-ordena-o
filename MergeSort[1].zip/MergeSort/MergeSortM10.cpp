#include <iostream>
#include <vector>
#include <chrono>

using namespace std;
using namespace std::chrono;

// Variáveis globais para contar comparações e cópias
int contagemComparacoes = 0;
int contagemCopias = 0;

void merge(vector<int>& arr, int esquerda, int meio, int direita) {
    int n1 = meio - esquerda + 1;
    int n2 = direita - meio;

    vector<int> L(n1), R(n2);

    for (int i = 0; i < n1; ++i)
        L[i] = arr[esquerda + i];
    for (int j = 0; j < n2; ++j)
        R[j] = arr[meio + 1 + j];

    int i = 0, j = 0, k = esquerda;

    while (i < n1 && j < n2) {
        contagemComparacoes++;  // Incrementa a contagem de comparações
        if (L[i] <= R[j]) {
            arr[k++] = L[i++];
        } else {
            arr[k++] = R[j++];
        }
        contagemCopias++;  // Incrementa a contagem de cópias
    }

    while (i < n1) {
        arr[k++] = L[i++];
        contagemCopias++;  // Incrementa a contagem de cópias
    }
    while (j < n2) {
        arr[k++] = R[j++];
        contagemCopias++;  // Incrementa a contagem de cópias
    }
}

void mergeSort(vector<int>& arr, int esquerda, int direita) {
    if (esquerda < direita) {
        int meio = esquerda + (direita - esquerda) / 2;

        mergeSort(arr, esquerda, meio);
        mergeSort(arr, meio + 1, direita);

        merge(arr, esquerda, meio, direita);
    }
}

vector<int> gerarCrescente(int tamanho) {
    vector<int> arr(tamanho);
    for (int i = 0; i < tamanho; ++i)
        arr[i] = i + 1;
    return arr;
}

int main() {
    int tamanho = 10000;  // 10.000 elementos
    vector<int> arr = gerarCrescente(tamanho);

    auto inicio = high_resolution_clock::now();
    mergeSort(arr, 0, arr.size() - 1);
    auto fim = high_resolution_clock::now();

    auto duracao = duration_cast<milliseconds>(fim - inicio);
    cout << "Melhor Caso (10.000 elementos): " << duracao.count() << " ms" << endl;
    cout << "Comparações: " << contagemComparacoes << endl;
    cout << "Cópias: " << contagemCopias << endl;

    return 0;
}
