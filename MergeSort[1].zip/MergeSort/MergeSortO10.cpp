#include <iostream>
#include <vector>
#include <chrono>
#include <cstdlib>

using namespace std;
using namespace std::chrono;

// Variáveis globais para contar comparações e trocas
long long comparacoes = 0;
long long trocas = 0;

// Função para combinar os subarrays
void merge(vector<int>& arr, int esquerda, int meio, int direita) {
    int n1 = meio - esquerda + 1;
    int n2 = direita - meio;

    vector<int> L(n1), R(n2);

    for (int i = 0; i < n1; ++i)
        L[i] = arr[esquerda + i];
    for (int j = 0; j < n2; ++j)
        R[j] = arr[meio + 1 + j];

    int i = 0, j = 0, k = esquerda;

    while (i < n1 && j < n2) {
        comparacoes++; // Cada comparação entre L[i] e R[j]
        if (L[i] <= R[j]) {
            arr[k++] = L[i++];
        } else {
            arr[k++] = R[j++];
        }
        trocas++; // Cada vez que um valor é inserido no vetor arr
    }

    // Adiciona os elementos restantes de L
    while (i < n1) {
        arr[k++] = L[i++];
        trocas++;
    }

    // Adiciona os elementos restantes de R
    while (j < n2) {
        arr[k++] = R[j++];
        trocas++;
    }
}

// Função principal do Merge Sort
void mergeSort(vector<int>& arr, int esquerda, int direita) {
    if (esquerda < direita) {
        int meio = esquerda + (direita - esquerda) / 2;

        mergeSort(arr, esquerda, meio);
        mergeSort(arr, meio + 1, direita);

        merge(arr, esquerda, meio, direita);
    }
}

// Funções para gerar os casos
vector<int> gerarCrescente(int tamanho) {
    vector<int> arr(tamanho);
    for (int i = 0; i < tamanho; ++i)
        arr[i] = i + 1;
    return arr;
}

vector<int> gerarAleatorio(int tamanho) {
    vector<int> arr(tamanho);
    for (int i = 0; i < tamanho; ++i)
        arr[i] = rand() % (tamanho * 10);
    return arr;
}

vector<int> gerarDecrescente(int tamanho) {
    vector<int> arr(tamanho);
    for (int i = 0; i < tamanho; ++i)
        arr[i] = tamanho - i;
    return arr;
}

int main() {
    int tamanho = 10000; // Tamanho do vetor
    vector<int> arr = gerarAleatorio(tamanho);

    auto inicio = high_resolution_clock::now();
    mergeSort(arr, 0, arr.size() - 1);
    auto fim = high_resolution_clock::now();

    auto duracao = duration_cast<milliseconds>(fim - inicio);
    cout << "Caso Médio (10.000 elementos): " << duracao.count() << " ms" << endl;
    cout << "Comparações: " << comparacoes << endl;
    cout << "Trocas: " << trocas << endl;

    return 0;
}
